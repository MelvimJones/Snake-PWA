<template> 
    <div class="gradient"> 
        <v-container> 
            <v-row no-gutters> 
                <v-col v-for="(prod, i ) in produtos" :key="i"> 
                    <div id="cad"> 
                        <v-img :src="prod.imagem" center contain :alt="prod.descricao" width="200" height="200" /> 
                        <v-sheet id="descricao" class="ma-2 pa-2"> 
                            {{ prod.descricao }} 
                        </v-sheet> 
                    </div> 
                </v-col> 
            </v-row> 
        </v-container> 
    </div> 
</template> 
 
 
<script> 
 
import axios from 'axios' 
 
export default { 
 
    name: "ListaProdutos", 
 
    data() { 
        return { 
            searchTerm: '', 
            mensagens: { 
                salvoSucesso: false, 
                excluidoSucesso: false 
            }, 
            produto: {}, 
            produtos: [], 
        }; 
    }, 
    methods: { 
 
        async cancelar() { 
            this.produto = {} 
        }, 
 
        async carregarProdutos() { 
            //request para API, que retorna uma promisse  
            let request = await axios.get("https://crud-nodejs-teste-a0ntnpfpx-melvimjones.vercel.app/produtos") 
 
            //Ao finalizar o request, carregue os dados em json 
            this.produtos = await request.data 
 
            //exibir no consoel 
            console.log(this.produtos) 
        }, 
 
        async salvarProduto() { 
 
            if (this.produto._id == undefined || this.produto._id == "") { 
                this.cadastrarProduto() 
            } else { 
                this.alterarProduto() 
            } 
            this.cancelar() 
            this.mensagens.salvoSucesso = true 
 
            //temporizador 
            setTimeout(() => { 
                this.mensagens.salvoSucesso = false 
            }, 3000); 
        }, 
 
        async alterarProduto() { 
            await axios.put("https://crud-nodejs-teste-a0ntnpfpx-melvimjones.vercel.app/produtos?id=" + this.produto._id, this.produto) 
            this.carregarProdutos() 
            //alterar na tela 
        }, 
 
        async cadastrarProduto() { 
            let request = await axios.post("https://crud-nodejs-teste-a0ntnpfpx-melvimjones.vercel.app/produtos", this.produto) 
            let prod = await request.data 
            //altera na tela  
            this.produtos.push(prod) 
        }, 
        async editarProduto(id, i) { 
 
            //acessar do array e colocar no form 
            this.produto = { ...this.produtos[i] } 
        }, 
 
        async deletarProduto(id, i) { 
            await axios.delete("https://crud-nodejs-teste-a0ntnpfpx-melvimjones.vercel.app/produtos?id=" + id) 
 
            //excluir do array 
            this.produtos.splice(i, 1) 
 
            this.cancelar() 
            this.mensagens.excluidoSucesso = true 
 
            //temporizador 
            setTimeout(() => { 
                this.mensagens.excluidoSucesso = false 
            }, 3000); 
        } 
    }, 
 
    async created() { 
        console.log("Created....") 
        await this.carregarProdutos() 
    } 
 
}; 
 
 
</script> 